"""Review probes for tutorials/eva02_classification_colab.ipynb (row 25, NOTEBOOK review relay 2026-10-02).

Usage (each probe runs in its own fresh working directory; CPU only; install cell skipped via the
notebook's own DIMER_NOTEBOOK_CI_PREINSTALLED hook):

    python run_probes.py <notebook.ipynb> <probe> <workdir> <results.json>

Probes:
  P0  static source checks (no execution)
  P1  default path: every code cell in order at the defaults
  P2  pixel-digest overlap between the seeded 16-per-class subset's train and val parts (no model)
  P3  run after P1 in the same process: reload equivalence (in-memory fine-tuned vs reloaded), trainable count
  P4  BYOD dataset branch via a shimmed google.colab upload: compatible zip, then incompatible zips
  P5  BYOD single-image branch via shimmed upload: a text file named .png, an oversized image
  P6  sample-dataset digest mismatch: cell 17 with a wrong expected SHA-256 -> what the run reports
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

NB = Path(sys.argv[1]).resolve()
PROBE = sys.argv[2]
WORK = Path(sys.argv[3]).resolve()
RESULTS = Path(sys.argv[4]).resolve()

nb = json.loads(NB.read_text(encoding="utf-8"))
CELLS = nb["cells"]
CODE = [i for i, c in enumerate(CELLS) if c["cell_type"] == "code"]


def src(i: int) -> str:
    return "".join(CELLS[i]["source"])


def record(key: str, value) -> None:
    data = json.loads(RESULTS.read_text(encoding="utf-8")) if RESULTS.exists() else {}
    data[key] = value
    RESULTS.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


class Upload:
    """Shim for google.colab.files.upload(): returns the queued {name: bytes} dict."""

    queue: list[dict] = []

    @classmethod
    def upload(cls):
        return cls.queue.pop(0)


def install_colab_shim() -> None:
    g = types.ModuleType("google")
    colab = types.ModuleType("google.colab")
    files = types.ModuleType("google.colab.files")
    files.upload = Upload.upload
    colab.files = files
    g.colab = colab
    sys.modules.update({"google": g, "google.colab": colab, "google.colab.files": files})


def run_cell(ns: dict, i: int, source: str | None = None) -> dict:
    code = source if source is not None else src(i)
    t0 = time.time()
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    err = None
    try:
        exec(compile(code, f"<cell {i}>", "exec"), ns)
    except BaseException as exc:  # noqa: BLE001 - probes record every failure
        err = f"{type(exc).__name__}: {exc}"
        tb = traceback.format_exc(limit=3)
    finally:
        sys.stdout = old
    out = buf.getvalue()
    res = {"cell": i, "ok": err is None, "seconds": round(time.time() - t0, 1), "stdout_tail": out[-1500:]}
    if err:
        res["error"] = err[:800]
        res["traceback_tail"] = tb[-800:]
    print(f"cell {i}: ok={res['ok']} {res['seconds']}s {err or ''}", file=sys.stderr)
    return res


def fresh_ns() -> dict:
    os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
    os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
    WORK.mkdir(parents=True, exist_ok=True)
    os.chdir(WORK)
    return {"__name__": "__main__"}


def default_path(ns: dict, stop_before: int | None = None) -> list[dict]:
    out = []
    for i in CODE:
        if stop_before is not None and i >= stop_before:
            break
        out.append(run_cell(ns, i))
        if not out[-1]["ok"]:
            break
    return out


def png_bytes(size=(32, 32), color=(10, 200, 30)) -> bytes:
    from PIL import Image

    b = io.BytesIO()
    Image.new("RGB", size, color).save(b, format="PNG")
    return b.getvalue()


def make_zip(entries: dict[str, bytes]) -> bytes:
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w") as z:
        for k, v in entries.items():
            z.writestr(k, v)
    return b.getvalue()


# --------------------------------------------------------------------------------------------
if PROBE == "P0":
    allsrc = "\n".join(src(i) for i in range(len(CELLS)))
    md = "\n".join(src(i) for i, c in enumerate(CELLS) if c["cell_type"] == "markdown").lower()
    c17, c19 = src(17), src(19)
    module = src(5)
    record("P0", {
        "cells": len(CELLS), "code_cells": len(CODE),
        "code_cell_lines": {i: src(i).count("\n") + 1 for i in CODE},
        "declared_spec": nb["metadata"]["dimer"]["notebook_spec"],
        "mode": nb["metadata"]["dimer"]["notebook_mode"], "profile": nb["metadata"]["dimer"]["notebook_profile"],
        "pip_install_in_kernel": "'pip', 'install'" in src(3),
        "uses_uv": "uv venv" in allsrc or "uv pip" in allsrc,
        "restart_instruction_present": "Restart the runtime" in src(3),
        "cellView_form_cells": [i for i, c in enumerate(CELLS) if c.get("metadata", {}).get("cellView") == "form"],
        "guided_markers": {k: (k.replace("_", " ") in md) for k in [
            "how_to_use", "roadmap", "glossary", "predict", "check_your_reasoning", "what_to_notice",
            "troubleshooting", "conclusion", "infrastructure", "intended learner"]},
        "fit_optimizer_over_all_parameters": "torch.optim.AdamW(model.parameters()" in module,
        "fit_freezes_any_parameter": "requires_grad" in module,
        "prose_says_head": ("classification head fine-tuning" in src(0)) or ("head adaptation" in src(0)),
        "prose_states_trainable_count_or_full_finetune": any(s in md for s in ["all parameters", "full fine-tun", "backbone is also", "trainable"]),
        "eval_verdict_hard_coded_success": "'verdict': 'success'" in c19,
        "reload_compared_to_in_memory": "fine_tuned_pipe" in c19 or "tolerance" in c19.lower(),
        "fine_tuned_pipe_used_after_cell17": any("fine_tuned_pipe" in src(i) for i in CODE if i > 17),
        "sample_download_broad_except_fallback": "except Exception" in c17 and "falling back" in c17,
        "digest_mismatch_inside_try": c17.find("SHA-256 mismatch") < c17.find("except Exception"),
        "byod_dataset_calls_validate_inputs": "validate_inputs" in c17,
        "byod_dataset_new_data_inference": False,  # cell 19 scores val only; no unseen/new-data inference
        "majority_baseline_tie_break": "max(set(val_labels), key=val_labels.count)" in c19,
        "atomic_write_claimed": "atomically" in src(16),
        "module_writes_atomically": ("os.replace" in module) or (".tmp" in module),
        "interpretation_mentions_fine_tune_result": any(s in src(22).lower() for s in ["accuracy", "validation", "6 images", "lift"]),
        "release_doc_procedure_mentions_finetune": None,  # filled by reviewer from docs/release-verification.md
    })

elif PROBE == "P1":
    ns = fresh_ns()
    t0 = time.time()
    cells = default_path(ns)
    res = {"cells": cells, "completed": sum(c["ok"] for c in cells), "of": len(CODE), "wall_s": round(time.time() - t0, 1)}
    if all(c["ok"] for c in cells):
        import torch
        from safetensors.torch import load_file

        # P3: reload equivalence and what was trained
        ft, rl = ns["fine_tuned_pipe"], ns["reloaded_pipe"]
        diffs, agree = [], 0
        for img in ns["val_images"]:
            a = ft.predict(img, top_k=2)["predictions"][0]
            b = rl.predict(img, top_k=2)["predictions"][0]
            agree += a["predicted_index"] == b["predicted_index"]
            sa = {t["index"]: t["score"] for t in a["top_k"]}
            sb = {t["index"]: t["score"] for t in b["top_k"]}
            diffs.append(max(abs(sa[k] - sb[k]) for k in sa))
        art = Path(ns["ft_output_dir"]) / "model.safetensors"
        tensors = load_file(str(art))
        base = load_file(str(Path(ns["WEIGHTS_DIR"]) / "model.safetensors"))
        changed = [k for k in tensors if k in base and tensors[k].shape == base[k].shape and not torch.equal(tensors[k], base[k])]
        res["P3"] = {
            "val_label_agreement": f"{agree}/{len(ns['val_images'])}",
            "max_abs_score_diff_in_memory_vs_reloaded": max(diffs),
            "artifact_bytes": art.stat().st_size,
            "artifact_tensors": len(tensors),
            "artifact_parameters": int(sum(t.numel() for t in tensors.values())),
            "backbone_tensors_changed_vs_base": len(changed),
            "backbone_tensors_compared": sum(1 for k in tensors if k in base and tensors[k].shape == base[k].shape),
            "example_changed": changed[:3],
            "train_meta": ns["train_meta"],
            "finetuned_eval_report": ns["finetuned_eval_report"],
            "outputs": sorted(os.listdir("outputs")),
        }
    record("P1", res)

elif PROBE == "P2":
    # Reproduce cell 17's seeded subset selection on the archive (no model) and check pixel copies.
    import random

    import numpy as np
    from PIL import Image

    zpath = Path(sys.argv[5])
    z = zipfile.ZipFile(zpath)
    names = [n for n in z.namelist() if n.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".bmp")) and not n.startswith("__MACOSX")]
    cls_files: dict[str, list[str]] = {}
    for n in names:
        cls_files.setdefault(n.strip("/").split("/")[-2], []).append(n)
    def dig(n):
        return hashlib.sha256(np.asarray(Image.open(io.BytesIO(z.read(n))).convert("RGB")).tobytes()).hexdigest()
    alld = {n: dig(n) for n in names}
    pairs_identical = sum(1 for n in names if "original_images" in n and alld.get(n.replace("original_images", "darkened_images")) == alld[n])
    rng = random.Random(42)
    train, val = [], []
    for cls, files in cls_files.items():  # same iteration order as the cell (insertion order)
        f = list(files); rng.shuffle(f); f = f[:16]
        nv = max(1, int(len(f) * 0.2))
        val += f[:nv]; train += f[nv:]
    tr = {alld[n] for n in train}
    stem = lambda n: n.replace("darkened_images", "X").replace("original_images", "X")  # noqa: E731
    trs = {stem(n) for n in train}
    record("P2", {
        "archive_images": len(names), "classes": {k: len(v) for k, v in cls_files.items()},
        "original_darkened_pairs_pixel_identical": pairs_identical,
        "subset_train": len(train), "subset_val": len(val),
        "val_files": val,
        "val_exact_pixel_copy_in_train": sum(alld[n] in tr for n in val),
        "val_counterpart_in_train": sum(stem(n) in trs for n in val),
        "val_darkened_share": sum("darkened" in n for n in val),
    })

elif PROBE == "P4":
    install_colab_shim()
    ns = fresh_ns()
    pre = default_path(ns, stop_before=17)
    assert all(c["ok"] for c in pre), pre
    c17 = src(17).replace("USE_BYOD_DATASET = False", "USE_BYOD_DATASET = True")
    out = {}
    # (a) compatible: two class folders x 5 images each (un-split -> seeded 80/20)
    good = {f"mydata/{c}/{i}.png": png_bytes((40 + i, 30), col) for c, col in [("red", (220, 20, 20)), ("blue", (20, 20, 220))] for i in range(5)}
    Upload.queue = [{"good.zip": make_zip(good)}]
    out["a_compatible_class_folders"] = [run_cell(ns, 17, c17), run_cell(ns, 19)]
    out["a_counts"] = {"train": len(ns.get("train_images", [])), "val": len(ns.get("val_images", []))}
    cases = {
        "b_one_class": {"d/only/1.png": png_bytes(), "d/only/2.png": png_bytes()},
        "c_non_image_member": {"d/a/1.png": png_bytes(), "d/a/2.png": b"not an image", "d/b/1.png": png_bytes(), "d/b/2.png": png_bytes()},
        "d_presplit_val_missing_class": {"d/train/a/1.png": png_bytes(), "d/train/b/1.png": png_bytes(), "d/val/a/1.png": png_bytes()},
        "e_traversal": {"../evil/a.png": png_bytes(), "d/b/1.png": png_bytes()},
        "f_no_images": {"d/readme.txt": b"hello"},
        "g_oversized_image_side": {"d/a/1.png": png_bytes((5000, 4)), "d/a/2.png": png_bytes((5000, 4)), "d/b/1.png": png_bytes(), "d/b/2.png": png_bytes()},
    }
    for name, entries in cases.items():
        Upload.queue = [{f"{name}.zip": make_zip(entries)}]
        if name in ("d_presplit_val_missing_class", "g_oversized_image_side"):
            out[name] = [run_cell(ns, 17, c17), run_cell(ns, 19)]
        else:
            out[name] = [run_cell(ns, 17, c17)]
    Upload.queue = [{"data.tar": b"x"}]
    out["h_not_zip"] = [run_cell(ns, 17, c17)]
    record("P4", out)

elif PROBE == "P5":
    install_colab_shim()
    ns = fresh_ns()
    pre = default_path(ns, stop_before=9)
    assert all(c["ok"] for c in pre), pre
    c9 = src(9).replace("USE_BYOD = False", "USE_BYOD = True")
    out = {}
    Upload.queue = [{"notes.png": b"this is a text file"}]
    out["a_text_as_image"] = [run_cell(ns, 9, c9)]
    big = io.BytesIO()
    from PIL import Image

    Image.new("RGB", (4200, 50), (5, 5, 5)).save(big, format="PNG")
    Upload.queue = [{"wide.png": big.getvalue()}]
    out["b_oversized"] = [run_cell(ns, 9, c9), run_cell(ns, 11)]
    Upload.queue = [{}]
    out["c_cancelled_upload"] = [run_cell(ns, 9, c9)]
    record("P5", out)

elif PROBE == "P6":
    ns = fresh_ns()
    pre = default_path(ns, stop_before=17)
    assert all(c["ok"] for c in pre), pre
    c17 = src(17).replace("66f90a4f87d865e8eb653b62f10e754684075a32314177de76832349d4b1fb19", "0" * 64)
    out = {"cell17": run_cell(ns, 17, c17), "cell19": run_cell(ns, 19)}
    out["dataset_source"] = ns.get("dataset_source")
    out["classes"] = ns.get("CUSTOM_CLASSES")
    out["report_verdict"] = ns.get("finetuned_eval_report", {}).get("verdict")
    out["report_metrics"] = ns.get("finetuned_eval_report", {}).get("metrics")
    record("P6", out)
